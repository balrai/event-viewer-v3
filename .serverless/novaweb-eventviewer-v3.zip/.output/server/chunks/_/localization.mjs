import { G as replaceAll } from '../nitro/nitro.mjs';

class Localization {
  static localizeObject(original, ...maps) {
    return Object.assign({}, original, combineMaps(maps));
  }
  static localizeString(original, ...maps) {
    let result = original;
    for (const [k, v] of Object.entries(combineMaps(maps))) {
      if (typeof v === "string") {
        result = replaceAll(result, `{{${k}}}`, v);
      }
    }
    return result;
  }
}
function combineMaps(maps = []) {
  return Object.assign({}, ...maps);
}

export { Localization as L };
//# sourceMappingURL=localization.mjs.map
