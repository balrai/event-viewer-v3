import { d as defineEventHandler, g as getQuery, t as getUserSession, p as eventStorage, E as ErrorResponse, j as EventFacade, P as PublicResolution, y as PreEmailGenericResolution, S as SelfEmailGenericUniqueResolution, z as PreRegNoPwRecoveryResolution, O as OpenEnrollmentResolution, B as SelfEmailPasswordResolution, C as templateStorage, c as createError } from '../../nitro/nitro.mjs';
import { A as AnalyticsFacade } from '../../_/analytics-facade.mjs';
import { L as Localization } from '../../_/localization.mjs';
import 'assert';
import 'zlib';
import 'crypto';
import 'events';
import 'tty';
import 'buffer';
import 'stream';
import 'node:stream';
import 'http';
import 'https';
import 'http2';
import 'os';
import 'path';
import 'fs';
import 'url';
import 'fs/promises';
import 'process';
import 'child_process';
import 'util';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';

function failure(body) {
  return buildRawResponse(400, JSON.stringify(body));
}
function internalServerError(body) {
  if (body instanceof Error) {
    return buildRawResponse(500, JSON.stringify({
      error: "SERVER_EXCEPTION",
      message: body.message
    }));
  } else if (typeof body === "string") {
    return buildRawResponse(500, JSON.stringify({
      error: "SERVER_EXCEPTION",
      message: body
    }));
  }
  return buildRawResponse(500, JSON.stringify(body));
}
function buildRawResponse(statusCode, body, contentType) {
  return {
    statusCode,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true,
      "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
      // What is this?
      "Cache-Control": "no-cache",
      "Content-type": contentType || "Application/json"
    },
    body
  };
}

const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c;
  try {
    const query = getQuery(event);
    const { eventCode, path, rehearsal } = query;
    const { secure } = await getUserSession(event);
    let accessToken = void 0;
    if (secure) {
      accessToken = secure.accessToken;
    }
    let locale = Array.isArray(query.locale) ? query.locale[0] : (_a = query.locale) != null ? _a : void 0;
    const eventProfile = await eventStorage.getEventProfileByEventCode(eventCode);
    if (!eventProfile || !eventProfile.enabled) {
      return failure(ErrorResponse.EVENT_NOT_EXIST);
    }
    const { authPreset, eventId } = eventProfile;
    if (!locale) {
      locale = await EventFacade.getEventDefaultLocale(eventId);
    }
    const handler = new PublicResolution().setNext(new PreEmailGenericResolution()).setNext(new SelfEmailGenericUniqueResolution()).setNext(new PreRegNoPwRecoveryResolution()).setNext(new OpenEnrollmentResolution()).setNext(new SelfEmailPasswordResolution());
    const result = await handler.handle(
      event,
      eventProfile,
      authPreset,
      path,
      locale,
      accessToken,
      rehearsal
    );
    locale = result.data.locale || locale;
    if (result.success) {
      if (rehearsal != "true") {
        try {
          await AnalyticsFacade.recordPageVisit(
            event,
            eventId,
            (_b = result.data.session) == null ? void 0 : _b.sessionId,
            path,
            accessToken
          );
        } catch (e) {
          console.log("Error recording page visit: ", e);
        }
      } else {
        await AnalyticsFacade.recordRehearsalPageVisit(
          event,
          eventId,
          (_c = result.data.session) == null ? void 0 : _c.sessionId,
          path,
          accessToken
        );
      }
      let session = result.data.session;
      let livestateData = null;
      if (session) {
        try {
          livestateData = await eventStorage.getSessionLiveState(
            session.sessionId
          );
        } catch (e) {
          console.log("Error fetching livestate data:", e);
        }
      }
      if (!!session && session.sessionType === "Archive") {
        if (session.autoStart && session.endAt < (/* @__PURE__ */ new Date()).getTime()) {
          return {
            event: eventProfile,
            session: null,
            liveState: livestateData,
            htmlContent: await fullHtml(
              eventProfile.eventId,
              result.data.templateId,
              locale,
              result.data.recordType,
              result.data.recordId
            ),
            userSession: result.data.userSession,
            error: "UNAVAILABLE",
            path: result.path
          };
        }
      }
      console.log("userSession: ", result.data);
      return {
        event: eventProfile,
        session,
        liveState: livestateData,
        htmlContent: await fullHtml(
          eventProfile.eventId,
          result.data.templateId,
          locale,
          result.data.recordType,
          result.data.recordId
        ),
        userSession: result.data.userSession,
        path: result.path
      };
    } else {
      return {
        event: eventProfile,
        session: result.data.session,
        userSession: result.data.userSession,
        error: result.error.error,
        htmlContent: await fullHtml(
          eventProfile.eventId,
          eventProfile.error.templateId,
          locale,
          null,
          null
        ),
        path: result.path
      };
    }
  } catch (e) {
    console.log("e => ", e);
    return internalServerError(e);
  }
});
async function fullHtml(eventId, templateId, locale, recordType, recordId) {
  try {
    const templateProfile = await templateStorage.getTemplateProfile(
      eventId,
      templateId
    );
    if (!templateProfile) {
      throw new Error("Template profile not found");
    }
    const fullHtml2 = await templateStorage.getComponent(templateId, "FullHTML");
    if (!fullHtml2) {
      throw new Error("FullHTML component not found");
    }
    const templateLocale = await eventStorage.getLocalization(
      eventId,
      "Template",
      templateId,
      locale
    );
    let alternativeLocales = {};
    if (recordType && recordId && locale) {
      alternativeLocales = await eventStorage.getLocalization(
        eventId,
        recordType,
        recordId,
        locale
      );
    }
    return Localization.localizeString(
      fullHtml2.content,
      templateLocale == null ? void 0 : templateLocale.content,
      alternativeLocales == null ? void 0 : alternativeLocales.content
    );
  } catch (e) {
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      data: e
    });
  }
}

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
