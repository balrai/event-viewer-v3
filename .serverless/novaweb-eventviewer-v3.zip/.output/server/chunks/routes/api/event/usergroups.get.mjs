import { d as defineEventHandler, r as requireUserSession, g as getQuery, p as eventStorage, c as createError } from '../../../nitro/nitro.mjs';
import 'assert';
import 'zlib';
import 'crypto';
import 'events';
import 'tty';
import 'buffer';
import 'stream';
import 'node:stream';
import 'http';
import 'https';
import 'http2';
import 'os';
import 'path';
import 'fs';
import 'url';
import 'fs/promises';
import 'process';
import 'child_process';
import 'util';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';

const usergroups_get = defineEventHandler(async (event) => {
  try {
    const { eventId } = await requireUserSession(event);
    const query = getQuery(event);
    const eventProfile = await eventStorage.getProfile(eventId);
    if (!eventProfile) {
      return createError({
        statusCode: 404,
        statusMessage: "Event not found"
      });
    }
    const usergroups = await eventStorage.getUserGroups(eventId);
    return usergroups;
  } catch (e) {
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      data: e
    });
  }
});

export { usergroups_get as default };
//# sourceMappingURL=usergroups.get.mjs.map
