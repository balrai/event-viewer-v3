import { d as defineEventHandler, t as getUserSession, w as viewerSessionStorage, x as clearUserSession, c as createError } from '../../../nitro/nitro.mjs';
import 'assert';
import 'zlib';
import 'crypto';
import 'events';
import 'tty';
import 'buffer';
import 'stream';
import 'node:stream';
import 'http';
import 'https';
import 'http2';
import 'os';
import 'path';
import 'fs';
import 'url';
import 'fs/promises';
import 'process';
import 'child_process';
import 'util';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';

const logout_post = defineEventHandler(async (event) => {
  try {
    const session = await getUserSession(event);
    const { userId } = session.user;
    if (userId) {
      viewerSessionStorage.invalidateUserSessions(userId);
    }
    await clearUserSession(event);
    return { success: true };
  } catch (e) {
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      data: e
    });
  }
});

export { logout_post as default };
//# sourceMappingURL=logout.post.mjs.map
