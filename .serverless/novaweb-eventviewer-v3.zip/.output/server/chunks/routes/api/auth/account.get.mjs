import { d as defineEventHandler, r as requireUserSession, g as getQuery, a as rehearsalViewerStorage, c as createError, v as viewerStorage, s as setUserSession, b as setCookie } from '../../../nitro/nitro.mjs';
import 'assert';
import 'zlib';
import 'crypto';
import 'events';
import 'tty';
import 'buffer';
import 'stream';
import 'node:stream';
import 'http';
import 'https';
import 'http2';
import 'os';
import 'path';
import 'fs';
import 'url';
import 'fs/promises';
import 'process';
import 'child_process';
import 'util';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';

const account_get = defineEventHandler(async (event) => {
  try {
    const session = await requireUserSession(event);
    const { userId } = session.user;
    const query = getQuery(event);
    const rehearsal = query.rehearsal === "true";
    let user;
    if (rehearsal) {
      user = await rehearsalViewerStorage.getProfile(userId);
      if (!user) {
        return createError({
          statusCode: 404,
          statusMessage: "User not found"
        });
      }
    } else {
      user = await viewerStorage.getProfile(userId);
      if (!user) {
        return createError({
          statusCode: 404,
          statusMessage: "User not found"
        });
      }
    }
    await setUserSession(event, {
      ...session,
      user: {
        ...session.user,
        locale: user.locale
      }
    });
    setCookie(event, "nova.locale", user.locale || "en-US", {
      httpOnly: false,
      maxAge: 60 * 60 * 24 * 365
    });
    return user;
  } catch (e) {
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      data: e
    });
  }
});

export { account_get as default };
//# sourceMappingURL=account.get.mjs.map
