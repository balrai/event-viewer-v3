import { u as useRuntimeConfig, o as readBody, d as defineEventHandler, t as getUserSession, g as getQuery, c as createError } from '../../../nitro/nitro.mjs';
import 'assert';
import 'zlib';
import 'crypto';
import 'events';
import 'tty';
import 'buffer';
import 'stream';
import 'node:stream';
import 'http';
import 'https';
import 'http2';
import 'os';
import 'path';
import 'fs';
import 'url';
import 'fs/promises';
import 'process';
import 'child_process';
import 'util';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';

class ExternalApiHandler {
  async handle(event, path, method, query, accessToken) {
    const config = useRuntimeConfig();
    const baseUrl = config.public.apiEndpoint || "https://dev-api.novaweb.live";
    const url = `${baseUrl}/${Array.isArray(path) ? path.join("/") : path}`;
    console.log("url:", url, method, query, accessToken);
    const headers = {};
    if (accessToken) {
      headers["Authorization"] = accessToken;
    }
    const normalizedMethod = method.toString().toUpperCase();
    const response = await $fetch(url, {
      method: normalizedMethod,
      headers,
      params: query,
      body: ["POST", "PUT", "PATCH"].includes(normalizedMethod) ? await readBody(event) : void 0
    });
    console.log("external api response:", response);
    return response;
  }
}

const ____path_ = defineEventHandler(async (event) => {
  var _a;
  try {
    const {
      secure: { accessToken }
    } = await getUserSession(event);
    console.log("external api handler called");
    const path = (_a = event.context.params) == null ? void 0 : _a.path;
    const query = getQuery(event);
    const method = event.node.req.method || "GET";
    const externalApiHandler = new ExternalApiHandler();
    const result = await externalApiHandler.handle(
      event,
      path,
      method,
      query,
      accessToken
    );
    return result;
  } catch (e) {
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      data: e
    });
  }
});

export { ____path_ as default };
//# sourceMappingURL=_...path_.mjs.map
